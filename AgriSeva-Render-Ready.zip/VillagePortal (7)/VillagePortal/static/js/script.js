// Andhra Pradesh Districts & Cities

const teluguDistricts = {

"Alluri Sitharama Raju":"అల్లూరి సీతారామరాజు",
"Anakapalli":"అనకాపల్లి",
"Ananthapuramu":"అనంతపురము",
"Annamayya":"అన్నమయ్య",
"Bapatla":"బాపట్ల",
"Chittoor":"చిత్తూరు",
"Dr. B.R. Ambedkar Konaseema":"డా. బి.ఆర్. అంబేద్కర్ కోనసీమ",
"East Godavari":"తూర్పు గోదావరి",
"Eluru":"ఏలూరు",
"Guntur":"గుంటూరు",
"Kakinada":"కాకినాడ",
"Krishna":"కృష్ణా",
"Kurnool":"కర్నూలు",
"Nandyal":"నంద్యాల",
"NTR":"ఎన్‌టీఆర్",
"Palnadu":"పల్నాడు",
"Prakasam":"ప్రకాశం",
"SPSR Nellore":"ఎస్‌పీఎస్‌ఆర్ నెల్లూరు",
"Srikakulam":"శ్రీకాకుళం",
"Sri Sathya Sai":"శ్రీ సత్యసాయి",
"Tirupati":"తిరుపతి",
"Visakhapatnam":"విశాఖపట్నం",
"Vizianagaram":"విజయనగరం",
"West Godavari":"పశ్చిమ గోదావరి",
"YSR Kadapa":"వైఎస్ఆర్ కడప"

};
const data = {

"Dr. B.R. Ambedkar Konaseema":[
{en:"Amalapuram",te:"అమలాపురం"},
{en:"Mummidivaram",te:"ముమ్మిడివరం"},
{en:"Razole",te:"రాజోలు"},
{en:"Kothapeta",te:"కొత్తపేట"},
{en:"Ainavilli",te:"ఐనవిల్లి"},
{en:"Katrenikona",te:"కాట్రేనికోన"},
{en:"P. Gannavaram",te:"పీ. గన్నవరం"},
{en:"Ambajipeta",te:"అంబాజీపేట"},
{en:"I. Polavaram",te:"ఐ. పోలవరం"},
{en:"Mamidikuduru",te:"మామిడికుదురు"},
{en:"Allavaram",te:"అల్లవరం"},
{en:"Uppalaguptam",te:"ఉప్పలగుప్తం"},
{en:"Malikipuram",te:"మలికిపురం"}
],

"East Godavari":[
{en:"Rajamahendravaram",te:"రాజమహేంద్రవరం"},
{en:"Kadiyam",te:"కడియం"},
{en:"Rajanagaram",te:"రాజానగరం"},
{en:"Korukonda",te:"కొరుకొండ"},
{en:"Seethanagaram",te:"సీతానగరం"},
{en:"Gokavaram",te:"గోకవరం"},
{en:"Rangampeta",te:"రంగంపేట"},
{en:"Peddapuram",te:"పెద్దాపురం"},
{en:"Samalkot",te:"సామర్లకోట"},
{en:"Jaggampeta",te:"జగ్గంపేట"},
{en:"Yeleswaram",te:"ఏలేశ్వరం"},
{en:"Prathipadu",te:"ప్రత్తిపాడు"},
{en:"Gandepalli",te:"గండేపల్లి"},
{en:"Biccavolu",te:"బిక్కవోలు"},
{en:"Anaparthi",te:"అనపర్తి"},
{en:"Rajanagaram Rural",te:"రాజానగరం గ్రామీణం"},
{en:"Rajamahendravaram Rural",te:"రాజమహేంద్రవరం గ్రామీణం"},
{en:"Rajamahendravaram Urban",te:"రాజమహేంద్రవరం పట్టణం"}
],

"Eluru":[
{en:"Eluru",te:"ఏలూరు"},
{en:"Denduluru",te:"దెందులూరు"},
{en:"Unguturu",te:"ఉంగుటూరు"},
{en:"Pedavegi",te:"పెడవేగి"},
{en:"Kaikaluru",te:"కైకలూరు"},
{en:"Mudinepalli",te:"ముదినేపల్లి"},
{en:"Bhimadole",te:"భీమడోలు"},
{en:"Lingapalem",te:"లింగపాలెం"},
{en:"Jangareddygudem",te:"జంగారెడ్డిగూడెం"},
{en:"Koyyalagudem",te:"కొయ్యలగూడెం"},
{en:"Buttayagudem",te:"బుట్టాయగూడెం"},
{en:"Jeelugumilli",te:"జీలుగుమిల్లి"},
{en:"Kamavarapukota",te:"కామవరపుకోట"},
{en:"Dwaraka Tirumala",te:"ద్వారకా తిరుమల"}
],

"West Godavari":[
{en:"Bhimavaram",te:"భీమవరం"},
{en:"Narasapuram",te:"నరసాపురం"},
{en:"Palakollu",te:"పాలకొల్లు"},
{en:"Tadepalligudem",te:"తాడేపల్లిగూడెం"},
{en:"Tanuku",te:"తణుకు"},
{en:"Achanta",te:"ఆచంట"},
{en:"Attili",te:"ఆత్తిలి"},
{en:"Akiveedu",te:"ఆకివీడు"},
{en:"Undi",te:"ఉండి"},
{en:"Penumantra",te:"పెనుమంట్ర"},
{en:"Iragavaram",te:"ఇరగవరం"},
{en:"Veeravasaram",te:"వీరవాసరం"},
{en:"Peravali",te:"పేరావలి"},
{en:"Yelamanchili",te:"యలమంచిలి"},
{en:"Poduru",te:"పొదూరు"},
{en:"Mogalthur",te:"మొగల్తూరు"},
{en:"Ganapavaram",te:"గణపవరం"},
{en:"Pentapadu",te:"పెంటపాడు"},
{en:"Palacoderu",te:"పాలకొడేరు"},
{en:"Nidadavole",te:"నిడదవోలు"},
{en:"Chintalapudi",te:"చింతలపూడి"}
],
"Guntur":[
{en:"Guntur",te:"గుంటూరు"},
{en:"Tenali",te:"తెనాలి"},
{en:"Mangalagiri",te:"మంగళగిరి"},
{en:"Pedakakani",te:"పెడకాకాని"},
{en:"Tadikonda",te:"తాడికొండ"},
{en:"Ponnur",te:"పొన్నూరు"},
{en:"Amaravathi",te:"అమరావతి"},
{en:"Chebrolu",te:"చేబ్రోలు"},
{en:"Prathipadu",te:"ప్రత్తిపాడు"},
{en:"Phirangipuram",te:"ఫిరంగిపురం"},
{en:"Kollipara",te:"కొల్లిపర"},
{en:"Vatticherukuru",te:"వట్టిచెరుకూరు"},
{en:"Duggirala",te:"దుగ్గిరాల"},
{en:"Kakumanu",te:"కాకుమాను"},
{en:"Tullur",te:"తుళ్ళూరు"}
],

"Kakinada":[
{en:"Kakinada",te:"కాకినాడ"},
{en:"Kakinada Rural",te:"కాకినాడ గ్రామీణం"},
{en:"Karapa",te:"కరప"},
{en:"Pithapuram",te:"పిఠాపురం"},
{en:"Tuni",te:"తుని"},
{en:"Prathipadu",te:"ప్రత్తిపాడు"},
{en:"Samalkota",te:"సామర్లకోట"},
{en:"Uppada",te:"ఉప్పాడ"},
{en:"Gollaprolu",te:"గొల్లప్రోలు"},
{en:"Thondangi",te:"తొండంగి"},
{en:"Kotananduru",te:"కోటనందూరు"},
{en:"Rowthulapudi",te:"రౌతులపూడి"},
{en:"Sankhavaram",te:"శంఖవరం"},
{en:"Yeleswaram",te:"ఏలేశ్వరం"},
{en:"Kajuluru",te:"కాజులూరు"}
],

"Krishna":[
{en:"Machilipatnam",te:"మచిలీపట్నం"},
{en:"Gudivada",te:"గుడివాడ"},
{en:"Pedana",te:"పెడన"},
{en:"Avanigadda",te:"అవనిగడ్డ"},
{en:"Pamarru",te:"పామర్రు"},
{en:"Movva",te:"మొవ్వ"},
{en:"Bantumilli",te:"బంటుమిల్లి"},
{en:"Koduru",te:"కోడూరు"},
{en:"Gudlavalleru",te:"గుడ్లవల్లేరు"},
{en:"Challapalli",te:"చల్లపల్లి"},
{en:"Ghantasala",te:"ఘంటసాల"},
{en:"Kalidindi",te:"కాళిదిండి"},
{en:"Mandavalli",te:"మండవల్లి"},
{en:"Nagayalanka",te:"నాగాయలంక"},
{en:"Mopidevi",te:"మోపిదేవి"}
],

"Kurnool":[
{en:"Kurnool",te:"కర్నూలు"},
{en:"Adoni",te:"ఆదోని"},
{en:"Yemmiganur",te:"ఎమ్మిగనూరు"},
{en:"Kodumur",te:"కోడుమూరు"},
{en:"Pattikonda",te:"పత్తికొండ"},
{en:"Nandikotkur",te:"నందికొట్కూరు"},
{en:"Alur",te:"ఆలూరు"},
{en:"Devanakonda",te:"దేవనకొండ"},
{en:"Kosigi",te:"కోసిగి"},
{en:"Mantralayam",te:"మంత్రాలయం"},
{en:"C. Belagal",te:"సి. బెలగల్"},
{en:"Gudur",te:"గూడూరు"},
{en:"Orvakal",te:"ఓర్వకల్"},
{en:"Kallur",te:"కల్లూరు"},
{en:"Velgode",te:"వెలుగోడు"}
],

"Nandyal":[
{en:"Nandyal",te:"నంద్యాల"},
{en:"Atmakur",te:"ఆత్మకూరు"},
{en:"Banaganapalle",te:"బనగానపల్లె"},
{en:"Allagadda",te:"ఆళ్లగడ్డ"},
{en:"Dhone",te:"ధోన్"},
{en:"Koilkuntla",te:"కొయిలకుంట్ల"},
{en:"Srisailam",te:"శ్రీశైలం"},
{en:"Bethamcherla",te:"బేతంచెర్ల"},
{en:"Panyam",te:"పాణ్యం"},
{en:"Gadivemula",te:"గడివేముల"},
{en:"Mahanandi",te:"మహానంది"},
{en:"Owk",te:"ఓవ్క్"},
{en:"Sanjamala",te:"సంజమల"},
{en:"Dornipadu",te:"దోర్నిపాడు"},
{en:"Bandi Atmakur",te:"బండి ఆత్మకూరు"}
],
"NTR":[
{en:"Vijayawada",te:"విజయవాడ"},
{en:"Ibrahimpatnam",te:"ఇబ్రహీంపట్నం"},
{en:"Tiruvuru",te:"తిరువూరు"},
{en:"Jaggaiahpet",te:"జగ్గయ్యపేట"},
{en:"Gannavaram",te:"గన్నవరం"},
{en:"Mylavaram",te:"మైలవరం"},
{en:"Kanchikacherla",te:"కంచికచర్ల"},
{en:"Nandigama",te:"నందిగామ"},
{en:"Vatsavai",te:"వత్సవాయి"},
{en:"Penuganchiprolu",te:"పెనుగంచిప్రోలు"},
{en:"A. Konduru",te:"ఎ. కొండూరు"},
{en:"Chandarlapadu",te:"చందర్లపాడు"},
{en:"Gampalagudem",te:"గంపలగూడెం"},
{en:"Jaggayyapeta Rural",te:"జగ్గయ్యపేట గ్రామీణం"},
{en:"Veerullapadu",te:"వీరుల్లపాడు"}
],

"Palnadu":[
{en:"Narasaraopet",te:"నరసరావుపేట"},
{en:"Vinukonda",te:"వినుకొండ"},
{en:"Sattenapalle",te:"సత్తెనపల్లి"},
{en:"Piduguralla",te:"పిడుగురాళ్ల"},
{en:"Macherla",te:"మాచర్ల"},
{en:"Gurazala",te:"గురజాల"},
{en:"Bellamkonda",te:"బెల్లంకొండ"},
{en:"Durgi",te:"దుర్గి"},
{en:"Rentachintala",te:"రెంటచింతల"},
{en:"Karempudi",te:"కారెంపూడి"},
{en:"Machavaram",te:"మాచవరం"},
{en:"Nekarikallu",te:"నేకరికల్లు"},
{en:"Rajupalem",te:"రాజుపాలెం"},
{en:"Pedakurapadu",te:"పెడకూరపాడు"},
{en:"Chilakaluripet",te:"చిలకలూరిపేట"}
],

"Parvathipuram Manyam":[
{en:"Parvathipuram",te:"పార్వతీపురం"},
{en:"Palakonda",te:"పాలకొండ"},
{en:"Salur",te:"సాలూరు"},
{en:"Kurupam",te:"కురుపాం"},
{en:"Makkuva",te:"మక్కువ"},
{en:"Komarada",te:"కొమరాడ"},
{en:"Seethampeta",te:"సీతంపేట"},
{en:"Garugubilli",te:"గరుగుబిల్లి"},
{en:"Jiyyammavalasa",te:"జియ్యమ్మవలస"},
{en:"Balijipeta",te:"బలిజిపేట"},
{en:"Pachipenta",te:"పాచిపెంట"},
{en:"Gummalakshmipuram",te:"గుమ్మలక్ష్మీపురం"},
{en:"Bhamini",te:"భామిని"},
{en:"Veeraghattam",te:"వీరఘట్టం"},
{en:"Kothavalasa",te:"కొత్తవలస"}
],

"Prakasam":[
{en:"Ongole",te:"ఒంగోలు"},
{en:"Markapur",te:"మార్కాపురం"},
{en:"Chirala",te:"చీరాల"},
{en:"Addanki",te:"అద్దంకి"},
{en:"Kandukur",te:"కందుకూరు"},
{en:"Giddalur",te:"గిద్దలూరు"},
{en:"Podili",te:"పొదిలి"},
{en:"Yerragondapalem",te:"ఎర్రగొండపాలెం"},
{en:"Kanigiri",te:"కనిగిరి"},
{en:"Bestavaripeta",te:"బేస్తవారిపేట"},
{en:"Mundlamuru",te:"ముండ్లమూరు"},
{en:"Cumbum",te:"కంభం"},
{en:"Ardhaveedu",te:"అర్ధవీడు"},
{en:"Pullalacheruvu",te:"పుల్లలచెరువు"},
{en:"Donakonda",te:"దొనకొండ"}
],

"SPSR Nellore":[
{en:"Nellore",te:"నెల్లూరు"},
{en:"Kavali",te:"కావలి"},
{en:"Atmakur",te:"ఆత్మకూరు"},
{en:"Gudur",te:"గూడూరు"},
{en:"Sullurupeta",te:"సూళ్లూరుపేట"},
{en:"Venkatagiri",te:"వెంకటగిరి"},
{en:"Naidupeta",te:"నాయుడుపేట"},
{en:"Buchireddypalem",te:"బుచ్చిరెడ్డిపాలెం"},
{en:"Kovur",te:"కోవూరు"},
{en:"Indukurpet",te:"ఇందుకూరుపేట"},
{en:"Muthukur",te:"ముత్తుకూరు"},
{en:"Manubolu",te:"మనుబోలు"},
{en:"Sangam",te:"సంగం"},
{en:"Rapur",te:"రాపూరు"},
{en:"Podalakur",te:"పొదలకూరు"}
],

"Srikakulam":[
{en:"Srikakulam",te:"శ్రీకాకుళం"},
{en:"Amadalavalasa",te:"ఆముదాలవలస"},
{en:"Palasa",te:"పలాస"},
{en:"Tekkali",te:"టెక్కలి"},
{en:"Ichapuram",te:"ఇచ్చాపురం"},
{en:"Narasannapeta",te:"నరసన్నపేట"},
{en:"Etcherla",te:"ఎచ్చెర్ల"},
{en:"Kaviti",te:"కవిటి"},
{en:"Kotabommali",te:"కోటబొమ్మాళి"},
{en:"Pathapatnam",te:"పాతపట్నం"},
{en:"Hiramandalam",te:"హిరమండలం"},
{en:"Kothuru",te:"కొత్తూరు"},
{en:"Laveru",te:"లావేరు"},
{en:"Polaki",te:"పోలాకి"},
{en:"Ranastalam",te:"రణస్థలం"}
],

"Sri Sathya Sai":[
{en:"Puttaparthi",te:"పుట్టపర్తి"},
{en:"Penukonda",te:"పెనుకొండ"},
{en:"Hindupur",te:"హిందూపురం"},
{en:"Kadiri",te:"కదిరి"},
{en:"Parigi",te:"పరిగి"},
{en:"Madakasira",te:"మడకశిర"},
{en:"Roddam",te:"రోడ్డం"},
{en:"Somandepalli",te:"సోమందేపల్లి"},
{en:"Gudibanda",te:"గుడిబండ"},
{en:"Amarapuram",te:"అమరాపురం"},
{en:"Agali",te:"అగళి"},
{en:"Chilamathur",te:"చిలమత్తూరు"},
{en:"Lepakshi",te:"లేపాక్షి"},
{en:"Nallamada",te:"నల్లమడ"},
{en:"Tanakal",te:"తనకల్"}
],

"Tirupati":[
{en:"Tirupati",te:"తిరుపతి"},
{en:"Renigunta",te:"రేణిగుంట"},
{en:"Srikalahasti",te:"శ్రీకాళహస్తి"},
{en:"Puttur",te:"పుత్తూరు"},
{en:"Naidupeta",te:"నాయుడుపేట"},
{en:"Pakala",te:"పాకాల"},
{en:"Yerpedu",te:"ఏర్పేడు"},
{en:"Chandragiri",te:"చంద్రగిరి"},
{en:"Vadamalapeta",te:"వడమాలపేట"},
{en:"Ramachandrapuram",te:"రామచంద్రాపురం"},
{en:"Nagalapuram",te:"నాగలాపురం"},
{en:"Satyavedu",te:"సత్యవేడు"},
{en:"Varadaiahpalem",te:"వరదయ్యపాలెం"},
{en:"Narayanavanam",te:"నారాయణవనం"},
{en:"Pichatur",te:"పిచ్చాటూరు"}
],

"Visakhapatnam":[
{en:"Visakhapatnam",te:"విశాఖపట్నం"},
{en:"Bheemunipatnam",te:"భీమిలి"},
{en:"Gajuwaka",te:"గాజువాక"},
{en:"Anandapuram",te:"ఆనందపురం"},
{en:"Padmanabham",te:"పద్మనాభం"},
{en:"Pendurthi",te:"పెందుర్తి"},
{en:"Sabbavaram",te:"సబ్బవరం"},
{en:"Parawada",te:"పరవాడ"},
{en:"Duvvada",te:"దువ్వాడ"},
{en:"Madhurawada",te:"మధురవాడ"},
{en:"Gopalapatnam",te:"గోపాలపట్నం"},
{en:"Rushikonda",te:"రుషికొండ"},
{en:"Seethammadhara",te:"సీతమ్మధార"},
{en:"MVP Colony",te:"ఎంవీపీ కాలనీ"},
{en:"Kancharapalem",te:"కంచరపాలెం"}
],

"Vizianagaram":[
{en:"Vizianagaram",te:"విజయనగరం"},
{en:"Bobbili",te:"బొబ్బిలి"},
{en:"Cheepurupalli",te:"చీపురుపల్లి"},
{en:"Nellimarla",te:"నెల్లిమర్ల"},
{en:"Gajapathinagaram",te:"గజపతినగరం"},
{en:"Srungavarapukota",te:"శృంగవరపుకోట"},
{en:"Salur",te:"సాలూరు"},
{en:"Garividi",te:"గరివిడి"},
{en:"Bondapalli",te:"బొండపల్లి"},
{en:"Denkada",te:"దెంకాడ"},
{en:"Bhogapuram",te:"భోగాపురం"},
{en:"Jami",te:"జామి"},
{en:"Mentada",te:"మెంటాడ"},
{en:"Badangi",te:"బాడంగి"},
{en:"Gantyada",te:"గంట్యాడ"}
],

"YSR Kadapa":[
{en:"Kadapa",te:"కడప"},
{en:"Proddatur",te:"ప్రొద్దుటూరు"},
{en:"Pulivendula",te:"పులివెందుల"},
{en:"Jammalamadugu",te:"జమ్మలమడుగు"},
{en:"Badvel",te:"బద్వేల్"},
{en:"Kamalapuram",te:"కమలాపురం"},
{en:"Mydukur",te:"మైదుకూరు"},
{en:"Vempalle",te:"వేంపల్లె"},
{en:"Rajampet",te:"రాజంపేట"},
{en:"Yerraguntla",te:"ఎర్రగుంట్ల"},
{en:"Chapadu",te:"చాపాడు"},
{en:"Chennur",te:"చెన్నూరు"},
{en:"Khajipet",te:"ఖాజీపేట"},
{en:"Lingala",te:"లింగాల"},
{en:"Veerapunayunipalle",te:"వీరపునాయునిపల్లె"}
]
};
// Load Districts
function loadDistricts() {

    let district = document.getElementById("district");
    let city = document.getElementById("city");

    district.innerHTML = "";
    city.innerHTML = "";

    let telugu = document.documentElement.lang === "te";

    district.innerHTML = telugu
        ? "<option value=''>జిల్లాను ఎంచుకోండి</option>"
        : "<option value=''>Select District</option>";

    city.innerHTML = telugu
        ? "<option value=''>నగరం / మండలాన్ని ఎంచుకోండి</option>"
        : "<option value=''>Select City / Mandal</option>";

    for (let d in data) {

        district.innerHTML += `
            <option value="${d}">
                ${telugu ? teluguDistricts[d] : d}
            </option>
        `;

    }

}
function loadCities() {

    let district = document.getElementById("district").value;
    let city = document.getElementById("city");

    city.innerHTML = "";

    let telugu = document.documentElement.lang === "te";

    city.innerHTML = telugu
        ? "<option value=''>నగరం / మండలాన్ని ఎంచుకోండి</option>"
        : "<option value=''>Select City / Mandal</option>";

    if (district === "") return;

    data[district].forEach(function(item) {

        city.innerHTML += `
            <option value="${item.en}">
                ${telugu ? item.te : item.en}
            </option>
        `;

    });

}
window.onload = function () {
    loadDistricts();
};