from flask import Flask, render_template, request, redirect, session, flash
from database.db import create_tables, get_connection
from werkzeug.security import generate_password_hash, check_password_hash
import requests
import os

app = Flask(__name__)

app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-production")

# Weather API Key
WEATHER_API_KEY = os.environ.get("WEATHER_API_KEY", "")
# Create database and tables5d7cc68ea4baa56d50847483b20f69cez
create_tables()

@app.route("/")
def home():
    return render_template("index.html")


# ---------------- REGISTER ----------------

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        fullname = request.form["fullname"]
        mobile = request.form["mobile"]
        village = request.form["village"]
        district = request.form["district"]
        crop = request.form["crop"]
        land = request.form["land"]
        password = request.form["password"]
        confirm = request.form["confirm"]

        if password != confirm:
            flash("Passwords do not match")
            return redirect("/register")

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM users WHERE mobile=?", (mobile,))
        user = cursor.fetchone()

        if user:
            flash("Mobile Number Already Registered")
            conn.close()
            return redirect("/register")

        hashed_password = generate_password_hash(password)

        cursor.execute("""
        INSERT INTO users
        (fullname,mobile,village,district,crop,land,password)
        VALUES(?,?,?,?,?,?,?)
        """,
        (
            fullname,
            mobile,
            village,
            district,
            crop,
            land,
            hashed_password
        ))

        conn.commit()
        conn.close()

        flash("Registration Successful")
        return redirect("/login")

    return render_template("register.html")


# ---------------- LOGIN ----------------

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        mobile = request.form["mobile"]
        password = request.form["password"]

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM users WHERE mobile=?", (mobile,))
        user = cursor.fetchone()

        conn.close()

        if user and check_password_hash(user["password"], password):

            session["user"] = user["fullname"]

            return redirect("/dashboard")

        flash("Invalid Mobile Number or Password")

    return render_template("login.html")


# ---------------- DASHBOARD ----------------

# ---------------- DASHBOARD ----------------

@app.route("/dashboard")
def dashboard():

    # This prints the logged-in user in the terminal
    print(session)

    if "user" not in session:
        return redirect("/login")

    return render_template(
        "dashboard.html",
        name=session["user"]
    )

@app.route("/weather", methods=["GET", "POST"])
def weather():

    if "user" not in session:
        return redirect("/login")

    selected_city = ""
    temperature = "--"
    humidity = "--"
    wind = "--"
    condition = "--"

    if request.method == "POST":

        selected_city = request.form["city"]

        CITY_MAPPING = {
            "Malikipuram": "Amalapuram",
            "Mamidikuduru": "Amalapuram",
            "Allavaram": "Amalapuram",
            "Ambajipeta": "Amalapuram",
            "Ainavilli": "Amalapuram",
            "Katrenikona": "Amalapuram",
            "P. Gannavaram": "Amalapuram",
            "Uppalaguptam": "Amalapuram"
        }

        city = CITY_MAPPING.get(selected_city, selected_city)

        print("Selected city:", city)

        url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric"

        print("URL:", url)

        response = requests.get(url)

        print("Status Code:", response.status_code)
        print("Response Text:", response.text)

        data = response.json()

        if response.status_code == 200:
            temperature = data["main"]["temp"]
            humidity = data["main"]["humidity"]
            wind = data["wind"]["speed"]
            condition = data["weather"][0]["description"]
        else:
            condition = data.get("message", "Weather not available")

    return render_template(
        "weather.html",
        city=selected_city,
        temperature=temperature,
        humidity=humidity,
        wind=wind,
        condition=condition
    )
@app.route("/fertilizer", methods=["GET", "POST"])
def fertilizer():

    if "user" not in session:
        return redirect("/login")

    recommendation = ""

    if request.method == "POST":

        crop = request.form["crop"]
        season = request.form["season"]

        telugu = session.get("language") == "te"

        if crop == "Paddy":

            if season == "Rainy":
                recommendation = "యూరియా + DAP" if telugu else "Urea + DAP"

            elif season == "Winter":
                recommendation = "NPK 20:20:0"

            else:
                recommendation = "కంపోస్ట్ + యూరియా" if telugu else "Compost + Urea"

        elif crop == "Cotton":

            if season == "Rainy":
                recommendation = "DAP + పొటాష్" if telugu else "DAP + Potash"

            else:
                recommendation = "NPK 19:19:19"

        elif crop == "Maize":

            if season == "Rainy":
                recommendation = "యూరియా + DAP" if telugu else "Urea + DAP"

            else:
                recommendation = "NPK 20:20:20"

        elif crop == "Groundnut":

            recommendation = "జిప్సం + SSP" if telugu else "Gypsum + SSP"

        elif crop == "Sugarcane":

            recommendation = "యూరియా + పొటాష్" if telugu else "Urea + Potash"

        else:

            recommendation = (
                "సేంద్రీయ కంపోస్ట్"
                if telugu else
                "Organic Compost"
            )

    return render_template(
        "fertilizer.html",
        recommendation=recommendation
    )
@app.route("/crop", methods=["GET", "POST"])
def crop():

    if "user" not in session:
        return redirect("/login")

    recommendation = ""

    if request.method == "POST":

        land = request.form["land"]
        season = request.form["season"]

        telugu = session.get("language") == "te"

        if land == "Wet Land":

            if season == "Rainy":
                recommendation = "వరి" if telugu else "Paddy"

            elif season == "Winter":
                recommendation = "గోధుమ" if telugu else "Wheat"

            else:
                recommendation = "మొక్కజొన్న" if telugu else "Maize"

        elif land == "Dry Land":

            if season == "Rainy":
                recommendation = "వేరుశెనగ" if telugu else "Groundnut"

            elif season == "Winter":
                recommendation = "పత్తి" if telugu else "Cotton"

            else:
                recommendation = "చిరుధాన్యాలు" if telugu else "Millets"

        else:
            recommendation = (
                "వ్యవసాయ అధికారిని సంప్రదించండి"
                if telugu else
                "Consult Agriculture Officer"
            )

    return render_template(
        "crop.html",
        recommendation=recommendation
    )

@app.route("/market", methods=["GET", "POST"])
def market():

    if "user" not in session:
        return redirect("/login")

    market = None
    error = None

    if request.method == "POST":

        crop = request.form.get("crop")

        # Map our dropdown names to Farmer.in commodity IDs
        crop_mapping = {
            "Paddy": "rice",
            "Cotton": "cotton",
            "Maize": "maize",
            "Groundnut": "groundnut",
            "Sugarcane": "sugarcane"
        }

        commodity_id = crop_mapping.get(crop)

        if not commodity_id:

            telugu = session.get("language") == "te"

            error = (
                "ఈ పంటకు ధర అందుబాటులో లేదు."
                if telugu
                else "Price not available for this crop."
            )

        else:

            try:

                # Farmer.in Open API
                url = "https://farmer.in/api/open/prices.json"

                response = requests.get(
                    url,
                    timeout=15
                )

                print("Market API Status:", response.status_code)

                if response.status_code == 200:

                    data = response.json()

                    commodities = data.get("commodities", [])

                    print(
                        "Number of commodities:",
                        len(commodities)
                    )

                    # Find selected commodity
                    for item in commodities:

                        if item.get("id") == commodity_id:

                            market = item
                            break

                    if market is None:

                        telugu = session.get("language") == "te"

                        error = (
                            "ఈ పంటకు ధర అందుబాటులో లేదు."
                            if telugu
                            else "Price not available for this crop."
                        )

                else:

                    telugu = session.get("language") == "te"

                    error = (
                        "మార్కెట్ ధరల సేవ ప్రస్తుతం అందుబాటులో లేదు."
                        if telugu
                        else "Market price service is currently unavailable."
                    )

            except requests.exceptions.RequestException as e:

                print("Market API Connection Error:", e)

                telugu = session.get("language") == "te"

                error = (
                    "మార్కెట్ ధరలను పొందడంలో సమస్య ఏర్పడింది."
                    if telugu
                    else "Unable to fetch market prices."
                )

            except Exception as e:

                print("Market API Error:", e)

                telugu = session.get("language") == "te"

                error = (
                    "మార్కెట్ ధరలను పొందడంలో సమస్య ఏర్పడింది."
                    if telugu
                    else "Unable to fetch market prices."
                )

    return render_template(
        "market.html",
        market=market,
        error=error
    )
@app.route("/schemes", methods=["GET", "POST"])
def schemes():

    if "user" not in session:
        return redirect("/login")

    title = None
    benefits = None
    eligibility = None
    documents = None

    if request.method == "POST":

        scheme = request.form.get("scheme")

        telugu = session.get("language") == "te"

        # =========================
        # TELUGU CONTENT
        # =========================

        if telugu:

            if scheme == "PM-KISAN":

                title = "PM-KISAN"

                benefits = (
                    "అర్హత కలిగిన రైతు కుటుంబాలకు సంవత్సరానికి "
                    "₹6,000 ఆర్థిక సహాయం అందించబడుతుంది. "
                    "ఈ మొత్తాన్ని మూడు విడతలుగా రైతుల బ్యాంకు ఖాతాల్లో జమ చేస్తారు."
                )

                eligibility = (
                    "సాగు భూమి కలిగి ఉన్న అర్హత కలిగిన రైతు కుటుంబాలు."
                )

                documents = (
                    "ఆధార్ కార్డు, బ్యాంకు ఖాతా వివరాలు, "
                    "భూమి పత్రాలు మరియు మొబైల్ నంబర్."
                )


            elif scheme == "Kisan Credit Card (KCC)":

                title = "కిసాన్ క్రెడిట్ కార్డ్ (KCC)"

                benefits = (
                    "రైతులకు వ్యవసాయ అవసరాల కోసం సులభంగా రుణం "
                    "పొందే అవకాశం కల్పిస్తుంది. పంట సాగు, "
                    "వ్యవసాయ పరికరాలు మరియు ఇతర వ్యవసాయ అవసరాలకు "
                    "రుణాన్ని ఉపయోగించుకోవచ్చు."
                )

                eligibility = (
                    "వ్యవసాయం, పాడి పరిశ్రమ లేదా మత్స్య రంగంలో "
                    "ఉన్న అర్హత కలిగిన రైతులు."
                )

                documents = (
                    "ఆధార్ కార్డు, PAN కార్డు, భూమి పత్రాలు, "
                    "బ్యాంకు వివరాలు మరియు పాస్‌పోర్ట్ సైజ్ ఫోటో."
                )


            elif scheme == "PMFBY Crop Insurance":

                title = "PMFBY పంటల బీమా"

                benefits = (
                    "ప్రకృతి వైపరీత్యాలు, తెగుళ్లు మరియు వ్యాధుల వల్ల "
                    "పంటలకు నష్టం జరిగినప్పుడు రైతులకు బీమా రక్షణ "
                    "మరియు ఆర్థిక పరిహారం అందిస్తుంది."
                )

                eligibility = (
                    "అర్హత కలిగిన రైతులు మరియు పంట రుణాలు తీసుకున్న "
                    "రైతులు ఈ పథకం ద్వారా ప్రయోజనం పొందవచ్చు."
                )

                documents = (
                    "ఆధార్ కార్డు, బ్యాంకు ఖాతా వివరాలు, "
                    "భూమి పత్రాలు, పంట వివరాలు మరియు రుణ వివరాలు."
                )


            elif scheme == "Soil Health Card":

                title = "భూసార ఆరోగ్య కార్డు"

                benefits = (
                    "రైతుల భూమిలోని పోషక పదార్థాల స్థాయిని తెలుసుకోవడానికి "
                    "మట్టి పరీక్ష చేయించి, సరైన ఎరువులు మరియు పోషక "
                    "పదార్థాల వినియోగంపై సూచనలు అందిస్తుంది."
                )

                eligibility = (
                    "వ్యవసాయ భూమి కలిగి ఉన్న రైతులు."
                )

                documents = (
                    "ఆధార్ కార్డు, భూమి వివరాలు మరియు "
                    "రైతు నమోదు వివరాలు."
                )


            elif scheme == "Organic Farming (PKVY)":

                title = "సేంద్రీయ వ్యవసాయం (PKVY)"

                benefits = (
                    "రసాయన ఎరువులు మరియు పురుగుమందుల వినియోగాన్ని "
                    "తగ్గించి సేంద్రీయ వ్యవసాయాన్ని ప్రోత్సహిస్తుంది. "
                    "సేంద్రీయ పద్ధతులతో పంటలను సాగు చేయడానికి రైతులకు "
                    "సహాయం మరియు మార్గదర్శకత్వం అందిస్తుంది."
                )

                eligibility = (
                    "సేంద్రీయ వ్యవసాయం చేయాలనుకునే రైతులు మరియు "
                    "రైతుల సమూహాలు."
                )

                documents = (
                    "ఆధార్ కార్డు, భూమి పత్రాలు, బ్యాంకు వివరాలు "
                    "మరియు రైతు నమోదు వివరాలు."
                )


        # =========================
        # ENGLISH CONTENT
        # =========================

        else:

            if scheme == "PM-KISAN":

                title = "PM-KISAN"

                benefits = (
                    "Eligible farmer families receive financial "
                    "assistance of ₹6,000 per year. The amount is "
                    "provided in three installments directly into "
                    "the farmer's bank account."
                )

                eligibility = (
                    "Eligible farmer families who own cultivable land."
                )

                documents = (
                    "Aadhaar Card, bank account details, "
                    "land documents and mobile number."
                )


            elif scheme == "Kisan Credit Card (KCC)":

                title = "Kisan Credit Card (KCC)"

                benefits = (
                    "Provides farmers easy access to credit for "
                    "agricultural needs. The credit can be used for "
                    "crop cultivation, agricultural equipment and "
                    "other farming requirements."
                )

                eligibility = (
                    "Eligible farmers involved in agriculture, "
                    "dairy or fisheries."
                )

                documents = (
                    "Aadhaar Card, PAN Card, land documents, "
                    "bank details and passport-size photograph."
                )


            elif scheme == "PMFBY Crop Insurance":

                title = "PMFBY Crop Insurance"

                benefits = (
                    "Provides insurance protection and financial "
                    "compensation to farmers when crops are damaged "
                    "due to natural disasters, pests or diseases."
                )

                eligibility = (
                    "Eligible farmers and farmers who have taken "
                    "crop loans can benefit from this scheme."
                )

                documents = (
                    "Aadhaar Card, bank account details, "
                    "land documents, crop details and loan details."
                )


            elif scheme == "Soil Health Card":

                title = "Soil Health Card"

                benefits = (
                    "Provides soil testing and recommendations about "
                    "the nutrient levels in the soil, along with "
                    "guidance on the appropriate use of fertilizers "
                    "and nutrients."
                )

                eligibility = (
                    "Farmers who own or cultivate agricultural land."
                )

                documents = (
                    "Aadhaar Card, land details and "
                    "farmer registration details."
                )


            elif scheme == "Organic Farming (PKVY)":

                title = "Organic Farming (PKVY)"

                benefits = (
                    "Promotes organic farming by reducing the use of "
                    "chemical fertilizers and pesticides. Provides "
                    "support and guidance to farmers for adopting "
                    "organic farming practices."
                )

                eligibility = (
                    "Farmers and farmer groups interested in "
                    "adopting organic farming."
                )

                documents = (
                    "Aadhaar Card, land documents, bank details "
                    "and farmer registration details."
                )


    return render_template(
        "schemes.html",
        title=title,
        benefits=benefits,
        eligibility=eligibility,
        documents=documents
    )
@app.route("/set_language/<lang>")
def set_language(lang):

    session["language"] = lang

    return redirect(request.referrer or "/dashboard")
# ---------------- LOGOUT ----------------

@app.route("/logout")
def logout():

    session.clear()

    return redirect("/")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)