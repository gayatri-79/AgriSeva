import sqlite3

DATABASE_NAME = "database.db"


def get_connection():
    conn = sqlite3.connect(DATABASE_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def create_tables():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fullname TEXT NOT NULL,
        mobile TEXT UNIQUE NOT NULL,
        village TEXT NOT NULL,
        district TEXT NOT NULL,
        crop TEXT NOT NULL,
        land REAL NOT NULL,
        password TEXT NOT NULL
    )
    """)

    conn.commit()
    conn.close()

    print("✅ Database and Users table created successfully.")